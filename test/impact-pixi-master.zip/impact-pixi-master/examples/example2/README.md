# ImpactPixi example

Using Spine

## Install

Just put your `impact` folder to `lib/`
