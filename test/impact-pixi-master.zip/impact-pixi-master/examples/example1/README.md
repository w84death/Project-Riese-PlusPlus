# ImpactPixi example

Basic usage of ImpactPixi

## Install

Just put your `impact` folder to `lib/`
