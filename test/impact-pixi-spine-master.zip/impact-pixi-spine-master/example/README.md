# Spine example for ImpactPixi

## Install

Just put your `impact` folder to `lib/`